package com.lab1.phone_book;

import android.content.Intent;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.lab1.phone_book.MESSAGE";
    public MyAsyncTask loadContacts;
    public List<Person> contacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loadContacts = new MyAsyncTask();
        loadContacts.execute();
    }

    /** Called when the user taps the Send button */
    public void sendMessage(View view) {
        Intent intent = new Intent(this, DisplayMessageActivity.class);
        EditText editText = findViewById(R.id.editText);
        String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }

    private class MyAsyncTask extends AsyncTask<Void, Void, List<Person>> {

        @Override
        protected List<Person> doInBackground(Void... params) {
            String fileContent;
            List<Person> contacts = new ArrayList<>();
            try {
                AssetManager assetManager = getApplicationContext().getAssets();
                InputStream stream = assetManager.open("contacts_data.json");
                Integer size = stream.available();
                byte[] bufer = new byte[size];
                stream.read(bufer);
                stream.close();
                fileContent = new String(bufer);
            }
            catch (IOException e){
                throw new RuntimeException(e);
            }
            try {
                JSONArray jsonArray = new JSONArray(fileContent);
                for (int i = 0; i < jsonArray.length(); i++){
                    JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                    Person person = new Person(jsonObject.getString("firstname"),
                            jsonObject.getString("lastname"),
                            jsonObject.getString("phone"),
                            jsonObject.getString("email"));
                    contacts.add(person);
                }
            } catch (JSONException e) {
                throw new RuntimeException(e);
//            e.printStackTrace();
            }
            return contacts;
        }

        @Override
        protected void onPostExecute(List<Person> result) {
            contacts = result;
            Log.d("tolol","" + contacts.size());
            Log.d("tolol","" + contacts.get(0).firstname);
            Log.d("tolol","" + contacts.get(0).lastname);
            Log.d("tolol","" + contacts.get(0).phone);
            Log.d("tolol","" + contacts.get(0).email);
        }
    }

//    List<Person> loadContacts(){
//        String fileContent;
//        List<Person> contacts = new ArrayList<>();
//        try {
//            AssetManager assetManager = getApplicationContext().getAssets();
//            InputStream stream = assetManager.open("contacts_data.json");
//            Integer size = stream.available();
//            byte[] bufer = new byte[size];
//            stream.read(bufer);
//            stream.close();
//            fileContent = new String(bufer);
//        }
//        catch (IOException e){
//            throw new RuntimeException(e);
//        }
//        try {
//            JSONArray jsonArray = new JSONArray(fileContent);
//            for (int i = 0; i < jsonArray.length(); i++){
//                 JSONObject jsonObject = (JSONObject) jsonArray.get(i);
//                 Person person = new Person(jsonObject.getString("firstname"),
//                         jsonObject.getString("lastname"),
//                         jsonObject.getString("phone"),
//                         jsonObject.getString("email"));
//                contacts.add(person);
//            }
//        } catch (JSONException e) {
//            throw new RuntimeException(e);
////            e.printStackTrace();
//        }
//        return contacts;
//    }
}
