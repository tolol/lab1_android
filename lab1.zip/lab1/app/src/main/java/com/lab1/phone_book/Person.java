package com.lab1.phone_book;

import java.io.Serializable;

public class Person implements Serializable {
    public String firstname;
    public String lastname;
    public String phone;
    public String email;

    Person(String firstname_, String lastname_, String phone_, String email_)
    {
        this.firstname = firstname_;
        this.lastname = lastname_;
        this.phone = phone_;
        this.email = email_;
    }

}
